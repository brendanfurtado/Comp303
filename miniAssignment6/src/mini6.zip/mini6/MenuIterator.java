//Student Name: Brendan Furtado
//Student ID: 260737867

import java.util.Iterator;

//Interface is used to iterate over Menu.java and Invoice.java
public interface MenuIterator {

    Iterator createIterator();

}
