package strategy.moreexamples;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * The Comparator interface in Java is an example of the Strategy pattern. This example shows how it can be used to sort
 * Student objects in different orders.
 * 
 * @author Mathieu
 */
public class ComparatorExample {
	
	public static void main(String[] args) {
		List<Student> students = new ArrayList<>();
		students.add(new Student("Alice", 10, 20, 30));
		students.add(new Student("Charles", 15, 15, 15));
		students.add(new Student("bob", 50, 0, 10));
		
		// Collections.sort(students);
		// ERROR: because Student is a new type, there's no way Java developers can know how to sort them.
		
		System.out.println(students);
		Collections.sort(students, new AscendingTotal());
		System.out.println(students);
		Collections.sort(students, new CaseInsensitiveName());
		System.out.println(students);
	}
}

/**
 * Our concrete strategy (concrete Comparator) to sort students.
 * 
 * @author Mathieu
 */
class AscendingTotal implements Comparator<Student> {
	
	/**
	 * Should return a negative number of o1 must be before o2, a positive number if o2 must be before o1, and 0 if
	 * neither is better than the other.
	 */
	@Override
	public int compare(Student o1, Student o2) {
		return (o1.getMathScore() + o1.getJavaScore() + o1.getCommScore())
				- (o2.getMathScore() + o2.getJavaScore() + o2.getCommScore());
	}
}

/**
 * Another comparator. Note that we are using the compareTo method already implemented in the String class, which can be
 * used to sort Strings alphabetically. We are only using toLowerCase() before, so that upper and lower case letters
 * don't matter.
 * 
 * @author Mathieu
 */
class CaseInsensitiveName implements Comparator<Student> {
	
	@Override
	public int compare(Student o1, Student o2) {
		return o1.getName().toLowerCase().compareTo(o2.getName().toLowerCase());
	}
}