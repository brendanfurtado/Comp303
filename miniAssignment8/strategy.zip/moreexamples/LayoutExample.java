package strategy.moreexamples;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.LayoutManager;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * Using the Strategy pattern implemented with the LayoutManagers. Each Container (e.g., a JPanel) contains Components
 * that must be laid out. Instead of relying on many parameters, the specific strategies necessary to place the elements
 * is extracted into a separate interface, LayoutManager. By creating our own implementation, we can change the layout
 * of new containers. This layout assumes a series of labels and input form elements. In particular, it assumes that
 * there is an even number of elements in the container. It also assumes that the height of the left elements (labels)
 * is always less than the height of the right elements, and elements will no resize to adapt to the container's
 * dimension. Finally, it assumes there are no margins to the container or between elements. As an exercise, you can try
 * modifying the code to relax these assumptions.
 * 
 * @author Mathieu
 */
public class LayoutExample implements LayoutManager {
	
	@Override
	public void addLayoutComponent(String name, Component comp) {
		// Do nothing. We don't need to know in advance all components.
		// See the implementation of BorderLayout for a non trivial implemnetation.
	}
	
	@Override
	public void removeLayoutComponent(Component comp) {
		// Do nothing. We don't need to know in advance all components.
		// See the implementation of BorderLayout for a non trivial implemnetation.
	}
	
	@Override
	public void layoutContainer(Container parent) {
		int x = 0;
		int y = 0;
		for (Component c : parent.getComponents()) {
			// Here, we would need to make more computations if we
			// were to adapt to the width of the container. Instead,
			// we just always use the same "preferred" size.
			Dimension d = c.getPreferredSize();
			c.setBounds(x, y, (int) d.getWidth(), (int) d.getHeight());
			if (x == 0) {
				x = (int) d.getWidth();
			}
			else {
				x = 0;
				y += d.getHeight();
			}
		}
	}
	
	@Override
	public Dimension preferredLayoutSize(Container parent) {
		int maxWidth = 0;
		int x = 0;
		int y = 0;
		for (Component c : parent.getComponents()) {
			Dimension d = c.getPreferredSize();
			if (x == 0) {
				x = (int) d.getWidth();
			}
			else {
				maxWidth = Math.max(maxWidth, x + (int) d.getWidth());
				x = 0;
				y += d.getHeight();
			}
		}
		return new Dimension(maxWidth, y);
	}
	
	@Override
	public Dimension minimumLayoutSize(Container parent) {
		int maxWidth = 0;
		int x = 0;
		int y = 0;
		for (Component c : parent.getComponents()) {
			// We are cheating here: the "minimum" size will just be
			// the "preferred" size, because our layout always uses the
			// preferred size.
			Dimension d = c.getMinimumSize();
			c.setBounds(x, y, (int) d.getWidth(), (int) d.getHeight());
			if (x == 0) {
				x = (int) d.getWidth();
			}
			else {
				maxWidth = Math.max(maxWidth, x + (int) d.getWidth());
				x = 0;
				y += d.getHeight();
			}
		}
		return new Dimension(maxWidth, y);
	}
	
	/**
	 * Main method to test our layout. It creates a small form, and makes it visible.
	 * 
	 * @param args
	 *            unused
	 */
	public static void main(String[] args) {
		JPanel form = new JPanel();
		form.setLayout(new LayoutExample());
		form.add(new JLabel("Name: "));
		form.add(new JTextField(20));
		form.add(new JLabel("Purpose: "));
		form.add(new JTextArea(10, 30));
		form.add(new JLabel("Java mastery: "));
		form.add(new JSlider(0, 100, 50));
		
		JFrame frame = new JFrame("Form");
		frame.setContentPane(form);
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
