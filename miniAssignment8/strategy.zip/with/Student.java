package strategy.with;

public class Student implements Comparable<Student> {
	
	private String name;
	private int mathScore;
	private int javaScore;
	private int commScore;
	
	@Override
	public int compareTo(Student other) {
		return name.toLowerCase().compareTo(other.name.toLowerCase());
	}
	
	public Student(String n, int m, int j, int c) {
		name = n;
		mathScore = m;
		javaScore = j;
		commScore = c;
	}
	
	public String getName() {
		return name;
	}
	
	public int getMathScore() {
		return mathScore;
	}
	
	public int getJavaScore() {
		return javaScore;
	}
	
	public int getCommScore() {
		return commScore;
	}
	
	@Override
	public String toString() {
		return "Student [name=" + name + ", mathScore=" + mathScore + ", javaScore=" + javaScore + ", commScore="
				+ commScore + "]";
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + commScore;
		result = prime * result + javaScore;
		result = prime * result + mathScore;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Student other = (Student) obj;
		if (commScore != other.commScore) {
			return false;
		}
		if (javaScore != other.javaScore) {
			return false;
		}
		if (mathScore != other.mathScore) {
			return false;
		}
		if (name == null) {
			if (other.name != null) {
				return false;
			}
		}
		else if (!name.equals(other.name)) {
			return false;
		}
		return true;
	}
}
