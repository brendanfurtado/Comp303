package strategy.with;

/**
 * The "Strategy" interface, with some implementations below. You can now add your own without changing anything from
 * any of these files (SelectionCommittee or SelectionStrategy).
 * 
 * @author Mathieu
 */
public interface SelectionStrategy {
	
	public boolean isGoodEnough(Student s);
}

class AlwaysFail implements SelectionStrategy {
	
	@Override
	public boolean isGoodEnough(Student s) {
		return false;
	}
}

class MinTotal implements SelectionStrategy {
	
	private int min;
	
	public MinTotal(int m) {
		min = m;
	}
	
	@Override
	public boolean isGoodEnough(Student s) {
		return s.getMathScore() + s.getJavaScore() + s.getCommScore() >= min;
	}
}
