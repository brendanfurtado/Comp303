package strategy.with;

import java.util.HashSet;
import java.util.Set;

/**
 * Same class, but with a Strategy (the SelectionStrategy). Now, we have a single variable (strategy) that replaces the
 * many previous parameters (mode, min, minJava, etc.), and the critical operation (isGoodEnough()) is moved outside the
 * class.
 * 
 * @author Mathieu
 */
public class SelectionCommittee {
	
	private Set<Student> students = new HashSet<>();
	private SelectionStrategy strategy = new AlwaysFail(); // some default strategy
	
	public void setStrategy(SelectionStrategy s) {
		strategy = s;
	}
	
	public void addStudent(Student s) {
		students.add(s);
	}
	
	public void select() {
		for (Student s : students) {
			// notice that isGoodEnough(s) is from another class, so we can easily change it
			if (strategy.isGoodEnough(s)) {
				System.out.println(s);
			}
		}
	}
	
	public static void main(String[] args) {
		SelectionCommittee committee = new SelectionCommittee();
		committee.setStrategy(new MinTotal(180));
		committee.addStudent(new Student("Alice", 95, 95, 10));
		committee.addStudent(new Student("Bob", 50, 50, 50));
		committee.addStudent(new Student("Charles", 30, 55, 90));
		committee.select();
	}
}
