package strategy.without;

import java.util.HashSet;
import java.util.Set;

/**
 * Represents a selection committee. This class contains a set of Students to choose from. When calling select(), all
 * students passing the minimum criteria are "selected" (printed to the console).
 * 
 * @author Mathieu
 */
public class SelectionCommittee {
	
	private Set<Student> students = new HashSet<>();
	
	// The problem is here: so many parameters to handle
	private String mode = "total";
	private int min = 0;
	private int minMath = 0;
	private int minJava = 0;
	private int minComm = 0;
	
	// And here: many setters makes the interface of the class harder to understand and use
	public void setSelectionByTotal(int minScore) {
		mode = "total";
		min = minScore;
	}
	
	public void setSelectionByIndividual(int minM, int minJ, int minC) {
		mode = "individual";
		minMath = minM;
		minJava = minJ;
		minComm = minC;
	}
	
	/**
	 * Add to the list of students.
	 * 
	 * @param s
	 *            new student to add
	 */
	public void addStudent(Student s) {
		students.add(s);
	}
	
	/**
	 * Checks each student one by one. If "good enough", prints the student in the console.
	 */
	public void select() {
		for (Student s : students) {
			if (isGoodEnough(s)) {
				System.out.println(s);
			}
		}
	}
	
	/**
	 * This is the important method. We need to decide whether the student should be selected or not. The selection
	 * process can depend on different criterias.
	 * 
	 * @param s
	 *            the student to judge
	 * @return true if the student should be selected
	 */
	private boolean isGoodEnough(Student s) {
		// Here, we are using a switch statement to select
		// the right way to do the selection. Note that the
		// code could become more complex as we add new ways
		// and variations to do this selection.
		// Instead of using different "modes", we could generalize
		// the selection criteria, but the effect would be the same:
		// higher (unnecessary) complexity to achieve some flexibility.
		switch (mode) {
			case "total":
				return s.getMathScore() + s.getJavaScore() + s.getCommScore() >= min;
			case "individual":
				return s.getMathScore() >= minMath && s.getJavaScore() >= minJava && s.getCommScore() >= minComm;
			default: // if the mode is wrong, just reject all students...
				return false;
		}
	}
	
	/**
	 * Sample driver program that checks the SelectionCommittee with 3 students.
	 * 
	 * @param args
	 *            unused
	 */
	public static void main(String[] args) {
		SelectionCommittee committee = new SelectionCommittee();
		committee.addStudent(new Student("Alice", 95, 95, 10));
		committee.addStudent(new Student("Bob", 50, 50, 50));
		committee.addStudent(new Student("Charles", 30, 55, 90));
		committee.select();
	}
}
